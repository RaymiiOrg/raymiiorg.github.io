
<div class="col_3">
	<h2>Links</h2>
	<p>
		<a href="index.php"><?php echo $LANG["mainpage"]; ?></a><br />

		<a href="full.php"><?php echo $LANG["monthlyoverview"]; ?></a><br />

	</p>
	<br />
	<h2><?php echo $LANG["help"]; ?></h2>
	<p>
		<?php echo $LANG["helptext"]; ?>
	</p>
	<h2><?php echo $LANG["info"]; ?></h2>
	<p>
		<?php echo $LANG["infotext"]; ?>
	</p>
</div><!-- div col3 --> 

<!-- Footer -->
<div class="col_12">
<hr />
<?php echo $productname . " " . $productversion; ?> by Remy van Elst - <a href="https://raymii.org">Raymii.org</a>.
</div>

</div>

</div>
</body></html>